package com.cts.ai.iot.smartmeter.controller;

import java.util.ArrayList;
import java.util.Properties;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.*;
import org.springframework.beans.factory.annotation.Autowired;


import com.cts.ai.iot.smartmeter.bean.VehicleSensorData;
import com.cts.ai.iot.smartmeter.model.VehicleSensor;
import com.cts.ai.iot.smartmeter.service.VehicleSensorService;

public class Producer {

	
	public boolean sendSensorData() {

		//Intializing Kafka server
	
		String bootstrapServers = "127.0.0.1:9092";
		Properties properties = new Properties();
		properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
		properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		
		
		KafkaProducer<String,String> first_producer = new KafkaProducer<String, String>(properties);
		//Send the processed vehicle data to Kafka
		ProducerRecord<String, String> record=new ProducerRecord<String, String>("SmartMeter Topic", "VehicleData");
		//Posting message to Kafka from the server
		first_producer.send(record);
		
		return true;
	};
}
