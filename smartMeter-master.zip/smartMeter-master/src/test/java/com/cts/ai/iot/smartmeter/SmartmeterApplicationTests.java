package com.cts.ai.iot.smartmeter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartmeterApplicationTests {

	@Test
	void contextLoads() {
	}

}
