DROP TABLE IF EXISTS vehicleinformation;

CREATE TABLE vehicleinformation(
  id INT AUTO_INCREMENT  PRIMARY KEY,
  date date,
  driverid VARCHAR(20),
  vehicleid VARCHAR(20),
  state VARCHAR(20),
  location VARCHAR(20),
  age Int,
  accidents  double,
  speeding double,
  claims double,
  vehicletype VARCHAR(20)
  
);

INSERT INTO vehicleinformation (date, driverid, vehicleid, state,location,age,accidents,speeding,claims,vehicletype ) VALUES
  ('2021-08-01','D1233','V2344','OH','43016','25','3','11','6','Sedan'),
  ('2021-08-01','D2475','V3234','OH','43016','31','0','2','0','SUV'),
  ('2021-08-01','D6345','V4345','SC','23615','40','6','0','4','Sedan'),
('2021-08-01','D7452','V5785','SC','23615','55','4','0','7','Suv'),
('2021-08-01','D8455','V6454','NY','10011','29','0','4','6','Sedan'),
('2021-08-01','D5234','V5457','NY','10011','42','4','7','4','Sedan'),
('2021-08-01','D3564','V8454','DC','20016','35','3','9','4','SUV'),
('2021-08-01','D5411','V2778','DC','20016','60','7','4','3','SUV'),
('2021-08-01','D9265','V7545','CA','92018','54','6','3','4','SUV'),
('2021-08-01','D9412','V9794','CA','92018','24','1','7','1','Sedan'),
('2021-08-01','D4213','V1574','IL','60606','40','8','7','4','Sedan'),
('2021-08-01','D1214','V8454','IL','60606','22','2','5','0','Sedan');


CREATE TABLE vehiclesensorinformation(
	id INT AUTO_INCREMENT  PRIMARY KEY,
	datereported VARCHAR,
	driverid VARCHAR(10),
	vehicleid VARCHAR(10),
	state VARCHAR(2),
	zip NUMBER,
	age NUMBER,
	sensortype VARCHAR(20),
	faultcount NUMBER
);

INSERT INTO vehiclesensorinformation (datereported, driverid, vehicleid, state,zip,age,sensortype,faultcount ) VALUES
  ('08-01-2021', 'D1233', 'V2344','OH',43016,25,'Brake Assist',4),
  ('08-01-2021', 'D1233', 'V2344','OH',43016,25,'Lane Assist',7),
  ('08-01-2021', 'D6345', 'V4345','SC',23615,40,'Brake Assist',2),
  ('08-01-2021', 'D6345', 'V4345','SC',23615,40,'Lane Assist',1),
  ('08-01-2021', 'D8455', 'V6454','NY',10011,29,'Brake Assist',6),
  ('08-01-2021', 'D8455', 'V6454','NY',10011,29,'Lane Assist',7),
  ('08-01-2021', 'D3564', 'V8454','DC',20016,35,'Brake Assist',1),
  ('08-01-2021', 'D3564', 'V8454','DC',20016,35,'Lane Assist',8),
  ('08-01-2021', 'D9265', 'V7545','CA',92018,54,'Brake Assist',5),
  ('08-01-2021', 'D9265', 'V7545','CA',92018,54,'Lane Assist',3),
  ('08-01-2021', 'D4213', 'V1574','IL',60606,40,'Brake Assist',4),
  ('08-01-2021', 'D4213', 'V1574','IL',60606,40,'Lane Assist',7);